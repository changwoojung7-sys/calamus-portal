import BrakeClient from "@/components/MainPortal/brake/BrakeClient";

export default function BrakePage() {
    return <BrakeClient />;
}
