declare module 'lunar-javascript';
